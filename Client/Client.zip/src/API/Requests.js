const API_KEY = "";

const requests = {
  AddUsers: `/..../...../...?key= ${API_KEY}&language=en-US`,
  AuthenticateUsers: `/..../...../...?key= ${API_KEY}&language=en-US`,
  Api_1: `/..../...../...?key= ${API_KEY}&language=en-US`,
  Api_2: `/..../...../...?key= ${API_KEY}&language=en-US`,
};

export default requests;
